create_clock -period 8.0 -waveform {0 4.0} clk
set_clock_latency -source 1.0 [get_clocks {clk}]
set_clock_uncertainty 0.03

