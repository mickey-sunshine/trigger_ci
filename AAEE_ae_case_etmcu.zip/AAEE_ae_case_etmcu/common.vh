`ifndef CPLD_COMMON_H
`define CPLD_COMMON_H

`define CPLD_FW_VER      		6'd40 

`define CMP_REG_WIDTH    		12
`define CMP_REG_MAX      		12'd4095

`define DB_REG_WIDTH     		8
`define DB_REG_MAX       		8'd255

// -----------------------------------------------
`define PWM_PRD_MIN		 		12'd48	// 全局最高频:2MHz，包含辅源发波
`define PWM_PRD_MAX		 		12'd4000

// -----------------------------------------------
`define PWM_DB_MIN		 		8'd10	// 单位为1/96 us
`define PWM_DB_MAX		 		8'd255	// 单位为1/96 us

`define SEC_CZ_DB		 		8'd2	// 高频互补死区，单位为1/96 us
`define PWR_OFF_STAGE1_DB  		8'd5    // 慢管续流期间的死区，单位为1/96 us
`define PWR_OFF_STAGE2_DB  		8'd20   // 其他模式切向S6/S7安全模式的死区，单位为1/96 us

// -----------------------------------------------
`define DAB_MODE_PRI_BOOTSTRAP 	3'd0
`define DAB_MODE_BUILD_AUX_PWR	3'd1
`define DAB_MODE_SEC_BOOTSTRAP 	3'd2
`define DAB_MODE_NORMAL_ON    	3'd3
`define DAB_MODE_NORMAL_OFF    	3'd4
`define DAB_MODE_S67_FREE_WHEEL	3'd5  	// 仅雷击测试时触发
`define DAB_MODE_ALL_DRV_OFF  	3'd7  	// 和上拉电阻状态相同

// -----------------------------------------------
`define PPI_CPLD_FRAME_LEN		5'd17
`define TRIG_OUT_PHASE_LEAD		12'd624 	// ADC采样保持--进入中断--退出中断的总时间

`define TRIG_OUT_DIV20_PRD		12'd96		// 1MHz以上 ~ 2MHz   20分频到[50, 100]Khz中断
`define TRIG_OUT_DIV10_PRD		12'd192		// 500K以上 ~ 1Mz    10分频到[50, 100]Khz中断
`define TRIG_OUT_DIV5_PRD		12'd240		// 400K以上 ~ 500Khz 5分频到[80, 100]Khz中断
`define TRIG_OUT_DIV4_PRD		12'd320		// 300K以上 ~ 400Khz 4分频到[75, 100]Khz中断
`define TRIG_OUT_DIV3_PRD		12'd480		// 200K以上 ~ 300Khz 3分频到[67, 100]Khz中断
`define TRIG_OUT_DIV2_PRD		12'd960		// 100K以上 ~ 200KHz 2分频到[50, 100]Khz中断

`endif

