`include "common.vh"

// Small business-boundary extraction of the existing MicInv CPLD top.
// clk is the already conditioned 96 MHz logic clock: PLL and pin constraints
// belong to the target integration. There is intentionally no added reset:
// original register power-up initializers remain the only initialization model.
//
// ADAPTER CONTRACT (NOT an ET/PPI physical-bus protocol):
// - All tuple inputs are synchronous to clk. On a rising edge with publish=1,
//   capture work_mode_cmd + period + both compares + both deadtimes together.
//   Upstream owns CDC, transport, validation, and any publication handshake.
// - Hold valid, stable parameters across that edge; compare values must fit the
//   selected period. Runtime limits/pipelines remain the original RTL's limits.
// - Publish is a software/business tuple handoff, not a gate-cycle commit or ACK.
//   The original comparator pipeline accepts period/compare at its wrap; DB
//   paths retain their separate per-edge/pipeline behavior. No common physical
//   activation boundary across all fields is claimed.
// - Mode commands are externally published: 7->0->1->2->3; no business scheduler
//   or analog readiness timing is implemented here. A fast fault selects 5;
//   mode 5 stays until a producer publishes 7. It does not auto-time to 7.
// - Discrete polarities match the old top: ready_n=0 means ready,
//   unlock_fault_n=0 requests clear, inv_oc_n=0 means OC, vg_pos_n=0 means
//   positive grid, vg_neg=1 means negative grid, normal_stop=1 requests mode 4.
// - Original IO_FLT_V1(10) filters remain. Its outputs initialize low, therefore
//   INV_OC can latch during power-up even with a healthy high inv_oc_n input.
//   Establish safe inputs and mode 7, wait for filters, pulse unlock low, and
//   observe fault_latched=0 before commanding startup. Clear never wins over
//   an active fault. Filtering does not establish board-level CDC safety.
//
// Retained: all eight gate equations, deadtime, startup helpers, mode FSM,
// shutdown stages 1/2, grid polarity handling, INV_OC/grid/FSM fault latches,
// and idle/working trigger generation. All rtl/original modules are unchanged
// logically (only documented encoding/newline normalization during extraction).
module micinv_minimal_top (
    // ET modify
    input xorFail,
    input rst_n,
    //
    input clk, 
    input publish,
    input [2:0] work_mode_cmd,
    input [11:0] pwm_prd, 
    input [11:0] cmp_pri_on_b, 
    input [11:0] cmp_sec_on_a,
    input [7:0] pri_pwm_db,
    input [7:0] sec_pwm_db,
    input ready_n,
    input unlock_fault_n,
    input normal_stop,
    input inv_oc_n,
    input vg_pos_n,
    input vg_neg,
    output S1,
    output S2,
    output S3,
    output S4,
    output S5,
    output S6,
    output S7,
    output S8,
    output [2:0] mode,
    output inv_oc_latched, 
    output fault_latched, 
    output fsm_fault_latched, 
    output grid_fault_latched,
    output trig_out
);
    reg [2:0] published_mode  ;
    reg [11:0] published_period  ;
    reg [11:0] published_pri_compare ;
    reg [11:0] published_sec_compare ;
    reg [7:0] published_pri_db ;
    reg [7:0] published_sec_db ;
    always @(posedge clk or negedge rst_n) begin
        if(rst_n == 1'b0)begin
            published_mode <= `DAB_MODE_ALL_DRV_OFF;
            published_period <= `PWM_PRD_MIN;
            published_pri_compare <=  12'd0;
            published_sec_compare <= 12'd0;
            published_pri_db <=  `PWM_DB_MIN;
            published_sec_db <=  `PWM_DB_MIN;
        end
        else if (publish) begin
            published_mode <= work_mode_cmd;
            published_period <= pwm_prd;
            published_pri_compare <= cmp_pri_on_b;
            published_sec_compare <= cmp_sec_on_a;
            published_pri_db <= pri_pwm_db;
            published_sec_db <= sec_pwm_db;
        end
    end

    wire filtered_ready_n, filtered_unlock_n, filtered_normal_stop;
    wire filtered_inv_oc_n, grid_positive, grid_negative;
    IO_FLT_V1 #(.FLT_NUM(10)) ready_filter(clk, rst_n,ready_n, filtered_ready_n);
    IO_FLT_V1 #(.FLT_NUM(10)) unlock_filter(clk,rst_n, unlock_fault_n, filtered_unlock_n);
    IO_FLT_V1 #(.FLT_NUM(10)) stop_filter(clk,rst_n, normal_stop, filtered_normal_stop);
    IO_FLT_V1 #(.FLT_NUM(10)) oc_filter(clk, rst_n,inv_oc_n, filtered_inv_oc_n);
    IO_FLT_V1 #(.FLT_NUM(10)) positive_filter(clk,rst_n, !vg_pos_n, grid_positive);
    IO_FLT_V1 #(.FLT_NUM(10)) negative_filter(clk, rst_n,vg_neg, grid_negative);

    wire fsm_fail;
    wire fast_stop = inv_oc_latched || filtered_ready_n;
    wire slow_stop = fault_latched || filtered_normal_stop;
    DAB_MODE_FSM mode_fsm (
        .clk(clk), 
        .rst_n(rst_n),
        .fastPwrOffIo(fast_stop), .slowPwrOffIo(slow_stop),
        .workModeCmd(published_mode), .workModeMux(mode), .fsmFail(fsm_fail)
    );

    // Other product-specific fault channels and PPI integrity checks were cut
    // at the documented boundary; constants do not model those protections.
    HW_FAULT faults (
        .clk(clk), 
        .rst_n(rst_n),
        .UNLOCK_FAULT(!filtered_unlock_n),
        .ICT_OC(1'b0), .INV_OC(!filtered_inv_oc_n), .CPLD_XOR_FAIL(xorFail),
        .vgCmpFail(grid_positive && grid_negative), .itCmpFail(1'b0),
        .secDrvShort(1'b0), .fsmFail(fsm_fail), .INV_OV(1'b0), .PV_OV(1'b0),
        .ictOcOst(), .invOcOst(inv_oc_latched), .xorFailOst(),
        .fsmFailOst(fsm_fault_latched), .vgCmpFailOst(grid_fault_latched),
        .itCmpFailOst(), .secDrvShortOst(), .invOvOst(), .pvOvOst(),
        .hasFault(fault_latched)
    );

    wire [7:0] startup_gates, normal_gates, stop1_gates, stop2_gates;
    wire work_trigger, idle_trigger;
    DAB_AUX_PWR startup_waveforms (
        .clk(clk), 
        .rst_n(rst_n),
        .workModeMux(mode), .pwmPrd(published_period),
        .priPwmDb(published_pri_db), .Sx(startup_gates)
    );
    DAB_EPS_V3 normal_waveforms (
        .clk(clk), 
        .rst_n(rst_n),
        .workModeMux(mode), .pwmPrd(published_period),
        .cmpPriOnB(published_pri_compare), .cmpSecOnA(published_sec_compare),
        .priPwmDb(published_pri_db), .secPwmDb(published_sec_db),
        .vgIsPos(grid_positive), .vgIsNeg(grid_negative),
        .itIsPos(1'b0), .itIsNeg(1'b0), .Sx(normal_gates), .trigOut(work_trigger)
    );
    DAB_PWR_OFF_STAGE1 ordinary_shutdown (
        .clk(clk), 
        .rst_n(rst_n),
        .workModeMux(mode), .vgIsPos(grid_positive), .vgIsNeg(grid_negative),
        .S5Mux(S5), .S6Mux(S6), .S7Mux(S7), .S8Mux(S8), .Sx(stop1_gates)
    );
    DAB_PWR_OFF_STAGE2 fast_shutdown (
        .clk(clk), 
        .rst_n(rst_n),
        .workModeMux(mode), .vgIsPos(grid_positive), .vgIsNeg(grid_negative),
        .S5Mux(S5), .S6Mux(S6), .S7Mux(S7), .S8Mux(S8), .Sx(stop2_gates), .debugOut()
    );
    DAB_PWM_MUX gate_mux (
        .clk(clk), 
        .rst_n(rst_n),
        .workModeMux(mode), .SxBuildAuxPwr(startup_gates),
        .SxNormalOn(normal_gates), .SxPwrOffStage1(stop1_gates), .SxPwrOffStage2(stop2_gates),
        .S1(S1), .S2(S2), .S3(S3), .S4(S4), .S5(S5), .S6(S6), .S7(S7), .S8(S8)
    );

    TRIG_SIGNAL idle_timing (
        .clk(clk), 
        .rst_n(rst_n),
        .rstN(mode != `DAB_MODE_NORMAL_ON), .trigOut(idle_trigger)
    );
    reg selected_trigger ;
    always @(posedge clk or negedge rst_n) begin
        if(rst_n == 1'b0)begin
            selected_trigger <= 1'd0;
        end
        else if (mode == `DAB_MODE_NORMAL_ON) selected_trigger <= work_trigger;
        else selected_trigger <= idle_trigger;
    end
    assign trig_out = selected_trigger;
endmodule
