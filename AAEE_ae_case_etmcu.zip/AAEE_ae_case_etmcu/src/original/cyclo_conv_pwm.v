`include "common.vh"

module cyclo_conv_pwm
(
    input clk,
    input rst_n,
    input rstN,
    input pwm0,
    input [`DB_REG_WIDTH - 1 : 0] pwmDb,
    input vgIsPos,
    input vgIsNeg,
    
    output [3:0] S
);

// ----------------------------------------------------------------------------
reg regP1_pwm0 ;
reg regP1_vgIsPos ;
reg regP1_vgIsNeg ;
reg [`DB_REG_WIDTH - 1 : 0] regP1_dbCnt;
reg [`DB_REG_WIDTH - 1 : 0] regP1_pwmDb ;


always@(posedge clk or negedge rst_n) begin 
    if(rst_n == 1'b0)begin
	    regP1_pwm0 <= 1'b0;
    end
    else begin
	    regP1_pwm0 <= pwm0;
    end
end


always@(posedge clk or negedge rst_n) begin 
    if(rst_n == 1'b0)begin
        regP1_dbCnt <= 'd0;
		regP1_vgIsPos <= 1'b0;
		regP1_vgIsNeg <= 1'd0;
        regP1_pwmDb <=`SEC_CZ_DB;
    end
    else if(!rstN) begin
        regP1_dbCnt <= 0;
		regP1_vgIsPos <= vgIsPos;
		regP1_vgIsNeg <= vgIsNeg;
        regP1_pwmDb <= 8'd20;
    end
    else begin
    	if (pwm0 != regP1_pwm0) begin
        	regP1_dbCnt <= 0;   // 上升/下降沿均清零死区计数器
    
        	if (pwm0) begin // 上升沿
            	regP1_vgIsPos <= vgIsPos;
            	regP1_vgIsNeg <= vgIsNeg;
            
            	// 过零区间用CPLD里面固定的最小死区，否则使用ARM传过来的正常死区
            	if (vgIsPos || vgIsNeg) begin
                	regP1_pwmDb <= pwmDb;
            	end
            	else begin
                	regP1_pwmDb <= `SEC_CZ_DB;
            	end
        	end
        	else begin      // 下降沿
        	end
    	end
    	else begin
        	if(regP1_dbCnt < `DB_REG_MAX) begin
            	regP1_dbCnt <= regP1_dbCnt + 1;
        	end
    	end
    end
end

// ----------------------------------------------------------------------------
reg [3:0] regP2_S ;

always@(posedge clk or negedge rst_n) begin 
    if(rst_n == 1'b0)begin
        regP2_S <= 4'd0;
    end
	else if(!rstN) begin
		regP2_S <= 4'b0000;
	end
	else begin
    	if(regP1_vgIsPos) begin
        	if(regP1_dbCnt >= regP1_pwmDb) begin
            	if(regP1_pwm0) begin
                	regP2_S <= 4'b1101;
            	end
            	else begin
                	regP2_S <= 4'b0111;
            	end
        	end
        	else begin
            	regP2_S <= 4'b0101;
        	end
    	end
    	else if(regP1_vgIsNeg) begin
        	if(regP1_dbCnt >= regP1_pwmDb) begin
            	if(regP1_pwm0) begin
                	regP2_S <= 4'b1011;
            	end
            	else begin
                	regP2_S <= 4'b1110;
            	end
        	end
        	else begin
            	regP2_S <= 4'b1010;
        	end
    	end
    	else begin
        	if(regP1_dbCnt >= regP1_pwmDb) begin
            	if(regP1_pwm0) begin
                	regP2_S <= 4'b1001;
            	end
            	else begin
                	regP2_S <= 4'b0110;
            	end
        	end
        	else begin
            	regP2_S <= 4'b0000;
        	end
    	end
	end
end

// ----------------------------------------------------------------------------
assign S = regP2_S;

endmodule
