`include "common.vh"

module DAB_AUX_PWR
(
    input       clk, 
    input rst_n,
    input [2:0] workModeMux,
    input [`CMP_REG_WIDTH - 1 : 0] pwmPrd,
    input [`DB_REG_WIDTH  - 1 : 0] priPwmDb,
    
    output [7:0] Sx
);

reg [`CMP_REG_WIDTH - 1 : 0] reg_pwmCnt ;
reg [`CMP_REG_WIDTH - 1 : 0] reg_pwmPrd ;
reg reg_s1raw ;
reg reg_s3raw ;
 
always@(posedge clk or negedge rst_n) begin 
    if(rst_n == 1'b0)begin
        reg_pwmCnt <= 'd0;
        reg_pwmPrd <= `PWM_PRD_MIN;
        reg_s1raw <= 'd0;                  
        reg_s3raw <= 'd0;                  
    end
    else begin
        case (workModeMux)
            // -----------------------------------------------------------
            `DAB_MODE_PRI_BOOTSTRAP: begin
                reg_pwmPrd <= pwmPrd;
                reg_pwmCnt <= 0;
                reg_s1raw <= 0;  // S1拉低则S2拉高,即自举
                reg_s3raw <= 0;  // S3拉低则S4拉高,即自举
             end

            // -----------------------------------------------------------
            `DAB_MODE_BUILD_AUX_PWR: begin
                if (reg_pwmCnt + 1 < reg_pwmPrd) begin 
                    reg_pwmCnt <= reg_pwmCnt + 1;
                   end
                else begin 
                    reg_pwmCnt <= 0;
                    reg_pwmPrd <= pwmPrd;
                end

                if(reg_pwmCnt < (reg_pwmPrd >>> 1)) begin
	    			reg_s1raw <= 1;
                    reg_s3raw <= 0;
                end
                else begin
	    		    reg_s1raw <= 0;
                    reg_s3raw <= 1;
                end
            end

            // -----------------------------------------------------------
            default: begin
                reg_pwmCnt <= 0;
                reg_s1raw <= 0;
                reg_s3raw <= 0;
            end
         endcase 
     end
end

wire wire_s1;
wire wire_s2;
wire wire_s3;
wire wire_s4;

pwm_db_v1 PRI_PWM_AH_AL
(
    .clk(clk),
    .rst_n(rst_n),
    .pwmDb(priPwmDb),
    .pwm0(reg_s1raw),
    .pwmH(wire_s1),
    .pwmL(wire_s2)
);

pwm_db_v1 PRI_PWM_BH_BL
(
    .clk(clk),
    .rst_n(rst_n),
    .pwmDb(priPwmDb),
    .pwm0(reg_s3raw),
    .pwmH(wire_s3),
    .pwmL(wire_s4)
);

assign Sx = {4'd0,        // S5~S8 OFF
             wire_s4, 
             wire_s3,
             wire_s2,
             wire_s1};

endmodule
