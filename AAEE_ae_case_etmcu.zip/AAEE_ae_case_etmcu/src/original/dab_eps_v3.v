`include "common.vh"

module DAB_EPS_V3
(
    input clk, 
    input rst_n,
    input [2:0] workModeMux,
    input [`DB_REG_WIDTH - 1 : 0] priPwmDb,
    input [`DB_REG_WIDTH - 1 : 0] secPwmDb,
    
    input [`CMP_REG_WIDTH - 1 : 0] pwmPrd,
    input [`CMP_REG_WIDTH - 1 : 0] cmpPriOnB,
    input [`CMP_REG_WIDTH - 1 : 0] cmpSecOnA,
    
    input vgIsPos,
    input vgIsNeg,

    input itIsPos,
    input itIsNeg,

    output [7:0]Sx,
    output trigOut
);

// ----------------------------------------------------------------------------
wire [`CMP_REG_WIDTH - 1 : 0] wire_pwmCnt;
wire [`CMP_REG_WIDTH - 1 : 0] wire_cmpPriPwm0A_On;
wire [`CMP_REG_WIDTH - 1 : 0] wire_cmpPriPwm0A_Off;
wire [`CMP_REG_WIDTH - 1 : 0] wire_cmpPriPwm0B_On;
wire [`CMP_REG_WIDTH - 1 : 0] wire_cmpPriPwm0B_Off;
wire [`CMP_REG_WIDTH - 1 : 0] wire_cmpSecPwm0_On;
wire [`CMP_REG_WIDTH - 1 : 0] wire_cmpSecPwm0_Off;

dab_cmp_v3 DAB_CMP
(
    .clk(clk),
    .rst_n(rst_n),
    .rstN((workModeMux == `DAB_MODE_NORMAL_ON) ? 1 : 0),
    
    .pwmPrd(pwmPrd),
    .cmpPriOnB(cmpPriOnB),
    .cmpSecOnA(cmpSecOnA),
    .cmpSecOnB(0),    // not used
    
    .pwmCnt(wire_pwmCnt),
    .cmpPriPwm0A_On (wire_cmpPriPwm0A_On),
    .cmpPriPwm0A_Off(wire_cmpPriPwm0A_Off),
    .cmpPriPwm0B_On (wire_cmpPriPwm0B_On),
    .cmpPriPwm0B_Off(wire_cmpPriPwm0B_Off),
    .cmpSecPwm0A_On (wire_cmpSecPwm0_On),
    .cmpSecPwm0A_Off(wire_cmpSecPwm0_Off),
    .cmpSecPwm0B_On(),    // not used
    .cmpSecPwm0B_Off(),   // not used
    .trigOut(trigOut)
);

// ----------------------------------------------------------------------------
wire wire_priPwm0A;
wire wire_priPwm0B;
wire wire_secPwm0;

dab_pwm0 PRI_PWM0A
(
    .clk(clk),
    .rst_n(rst_n),
    .pwmCnt(wire_pwmCnt),
    .cmpOn (wire_cmpPriPwm0A_On),
    .cmpOff(wire_cmpPriPwm0A_Off),
    .pwm0  (wire_priPwm0A)
);

dab_pwm0 PRI_PWM0B
(
    .clk(clk),
    .rst_n(rst_n),
    .pwmCnt(wire_pwmCnt),
    .cmpOn (wire_cmpPriPwm0B_On),
    .cmpOff(wire_cmpPriPwm0B_Off),
    .pwm0  (wire_priPwm0B)
);

dab_pwm0 SEC_PWM0
(
    .clk(clk),
    .rst_n(rst_n),
    .pwmCnt(wire_pwmCnt),
    .cmpOn (wire_cmpSecPwm0_On),
    .cmpOff(wire_cmpSecPwm0_Off),
    .pwm0  (wire_secPwm0)
);

// ----------------------------------------------------------------------------
reg [`DB_REG_WIDTH - 1 : 0] reg_safePriPwmDb;
reg [`DB_REG_WIDTH - 1 : 0] reg_safeSecPwmDb;

always@(posedge clk or negedge rst_n ) begin 
    if(rst_n == 1'b0)begin
        reg_safePriPwmDb <= `PWM_DB_MIN;
    end
    else if(priPwmDb < `PWM_DB_MIN)begin
        reg_safePriPwmDb <= `PWM_DB_MIN;
    end
    else if(priPwmDb > `PWM_DB_MAX)begin
        reg_safePriPwmDb <= `PWM_DB_MAX;
    end
    else begin
        reg_safePriPwmDb <= priPwmDb;
    end
end
    
always@(posedge clk or negedge rst_n ) begin 
    if(rst_n == 1'b0)begin
        reg_safeSecPwmDb <= `PWM_DB_MIN;
    end
    else if(secPwmDb < `PWM_DB_MIN)begin
        reg_safeSecPwmDb <= `PWM_DB_MIN;
    end
    else if(secPwmDb > `PWM_DB_MAX)begin
        reg_safeSecPwmDb <= `PWM_DB_MAX;
    end
    else begin
        reg_safeSecPwmDb <= secPwmDb;
    end
end

// ----------------------------------------------------------------------------
wire wire_s1;
wire wire_s2;
wire wire_s3;
wire wire_s4;

pwm_db_v1 PRI_PWM_AH_AL
(
    .clk(clk),
    .rst_n(rst_n),
    .pwmDb(reg_safePriPwmDb),
    .pwm0(wire_priPwm0A),
    .pwmH(wire_s1),
    .pwmL(wire_s2)
);

pwm_db_v1 PRI_PWM_BH_BL
(
    .clk(clk),
    .rst_n(rst_n),
    .pwmDb(reg_safePriPwmDb),
    .pwm0(wire_priPwm0B),
    .pwmH(wire_s3),
    .pwmL(wire_s4)
);

wire wire_s5;
wire wire_s6;
wire wire_s7;
wire wire_s8;

cyclo_conv_pwm SEC_PWM_5678
(
    .clk(clk),
    .rst_n(rst_n),
    .rstN((workModeMux == `DAB_MODE_NORMAL_ON) ? 1 : 0),
    .pwm0(wire_secPwm0),
    .pwmDb(reg_safeSecPwmDb),
    .vgIsPos(vgIsPos),
    .vgIsNeg(vgIsNeg),
    .S({wire_s5, wire_s6, wire_s7, wire_s8})
);

assign Sx[0] = wire_s1;
assign Sx[1] = wire_s2;
assign Sx[2] = wire_s3;
assign Sx[3] = wire_s4;
assign Sx[4] = wire_s5;
assign Sx[5] = wire_s6;
assign Sx[6] = wire_s7;
assign Sx[7] = wire_s8;

endmodule
