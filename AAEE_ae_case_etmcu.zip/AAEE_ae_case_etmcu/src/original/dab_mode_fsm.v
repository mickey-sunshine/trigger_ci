`include "common.vh"
 
module DAB_MODE_FSM
(
    input       clk, 
    input rst_n,

    // 输入
    input       fastPwrOffIo,    // 高优先级快速关机
    input       slowPwrOffIo,    // 中优先级正常关机
    input [2:0] workModeCmd,     // 低优先级并口指令
    
    // 输出
    output[2:0] workModeMux,
    output      fsmFail
);

reg [2:0] reg_workModeMux ;
reg reg_fsmFail;


always@(posedge clk or negedge rst_n) begin
    if(rst_n == 1'b0)begin
        reg_workModeMux <= `DAB_MODE_ALL_DRV_OFF;
        reg_fsmFail <= 1'd0;
    end
    else begin
        case (reg_workModeMux)
            // ############################################################
            // ####                 CPLD关所有驱动                       ####
            // ############################################################
            default: begin // `DAB_MODE_ALL_DRV_OFF
                reg_fsmFail <= 0;    // 跳回本状态后立即清零。即fsmFail只输出一个脉冲给hw_fault模块

                if(fastPwrOffIo || slowPwrOffIo) begin
                    reg_workModeMux <= `DAB_MODE_ALL_DRV_OFF; // stay here
                end
                else begin
                    if(workModeCmd == `DAB_MODE_PRI_BOOTSTRAP) begin
                        reg_workModeMux <= `DAB_MODE_PRI_BOOTSTRAP;
                    end
                end
            end

            // ############################################################
            // ####                   原边自举                          ####
            // ############################################################
            `DAB_MODE_PRI_BOOTSTRAP : begin
                if(fastPwrOffIo || slowPwrOffIo) begin
                    reg_workModeMux <= `DAB_MODE_ALL_DRV_OFF;
                end
                else begin
                    // 根据workModeCmd跳转
                    case (workModeCmd)    
                        // 合法指令
                        `DAB_MODE_PRI_BOOTSTRAP,
                        `DAB_MODE_BUILD_AUX_PWR,
                        `DAB_MODE_ALL_DRV_OFF: begin
                            reg_workModeMux <= workModeCmd;
                        end

                        // 异常指令
                        default:begin
                            reg_workModeMux <= `DAB_MODE_ALL_DRV_OFF;
                            reg_fsmFail <= 1;
                        end
                    endcase                // end of case (workModeCmd)
                end
            end
                
            // ############################################################
            // ####                    建立辅源                         ####
            // ############################################################
            `DAB_MODE_BUILD_AUX_PWR : begin
                if(fastPwrOffIo || slowPwrOffIo) begin
                    reg_workModeMux <= `DAB_MODE_ALL_DRV_OFF;
                end
                else begin
                    case (workModeCmd)    // 根据workModeCmd跳转
                        // 合法指令
                        `DAB_MODE_ALL_DRV_OFF,
                        `DAB_MODE_BUILD_AUX_PWR,
                        `DAB_MODE_SEC_BOOTSTRAP: begin
                            reg_workModeMux <= workModeCmd;
                        end

                        // 异常指令
                        default:begin
                            reg_workModeMux <= `DAB_MODE_ALL_DRV_OFF;
                            reg_fsmFail <= 1;
                        end
                    endcase                // end of case (workModeCmd)
                 end
             end

            // ############################################################
            // ####       辅源建立结束，正常拉功率前，先关所有驱动           ####
            // ############################################################
            `DAB_MODE_SEC_BOOTSTRAP: begin
                if(fastPwrOffIo || slowPwrOffIo) begin
                    reg_workModeMux <= `DAB_MODE_ALL_DRV_OFF;
                end
                else begin
                    case (workModeCmd)    // 根据workModeCmd跳转
                        // 合法指令
                        `DAB_MODE_ALL_DRV_OFF,
                        `DAB_MODE_SEC_BOOTSTRAP,
                        `DAB_MODE_NORMAL_ON: begin
                            reg_workModeMux <= workModeCmd;
                        end

                        // 异常指令
                        default:begin
                            reg_workModeMux <= `DAB_MODE_ALL_DRV_OFF;
                            reg_fsmFail <= 1;
                        end
                    endcase                // end of case (workModeCmd)
                end
            end

            // ############################################################
            // ####                     正常拉功率                       ####
            // ############################################################
            `DAB_MODE_NORMAL_ON : begin
                if(fastPwrOffIo) begin
                    reg_workModeMux <= `DAB_MODE_S67_FREE_WHEEL;
                end
                else if(slowPwrOffIo) begin
                    reg_workModeMux <= `DAB_MODE_NORMAL_OFF;
                end
                else begin
                    case (workModeCmd)    // 根据workModeCmd跳转
                        // 合法指令
                        `DAB_MODE_NORMAL_ON,
                        `DAB_MODE_NORMAL_OFF: begin
                            reg_workModeMux <= workModeCmd;
                        end

                        // 异常指令
                        default:begin
                            reg_workModeMux <= `DAB_MODE_NORMAL_OFF;  // MCU开始拉功率后，不允许直接拉所有驱动
                            reg_fsmFail <= 1;
                        end
                    endcase                // end of case (workModeCmd)
                end
            end

            // ############################################################
            // ####                正常关机，慢管续流                     ####
            // ############################################################
            `DAB_MODE_NORMAL_OFF : begin
                if(fastPwrOffIo || (`DAB_MODE_S67_FREE_WHEEL == workModeCmd)) begin
                    reg_workModeMux <= `DAB_MODE_S67_FREE_WHEEL;
                end
            end

            // ############################################################
            // ####               异常关机，S6/S7续流                    ####
            // ############################################################
            `DAB_MODE_S67_FREE_WHEEL : begin
                if(`DAB_MODE_ALL_DRV_OFF == workModeCmd) begin
                    reg_workModeMux <= `DAB_MODE_ALL_DRV_OFF;
                end
            end
        endcase
    end
end

assign workModeMux = reg_workModeMux;
assign fsmFail     = reg_fsmFail;

endmodule
