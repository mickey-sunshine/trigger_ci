`include "common.vh"

module dab_pwm0
(
    input clk,
    input rst_n,
    input [`CMP_REG_WIDTH - 1 : 0] pwmCnt,
    input [`CMP_REG_WIDTH - 1 : 0] cmpOn,
    input [`CMP_REG_WIDTH - 1 : 0] cmpOff,

    output pwm0
);

reg reg_pwm0 ;

always@(posedge clk or negedge rst_n) begin
    if(rst_n == 1'b0)begin
	     	reg_pwm0 <= 'd0;
    end
	else if(cmpOff < cmpOn) begin
	    if ((pwmCnt >= cmpOff) && (pwmCnt < cmpOn)) begin
	     	reg_pwm0 <= 0;
	    end
	    else begin
	        reg_pwm0 <= 1;
	    end
	end
	else begin
		if ((pwmCnt >= cmpOn) && (pwmCnt < cmpOff)) begin
	     	reg_pwm0 <= 1;
	    end
	    else begin
	        reg_pwm0 <= 0;
	    end
	end
end

assign pwm0 = reg_pwm0;

endmodule
