`include "common.vh"

module DAB_PWM_MUX
(
    input       clk, 
    input rst_n,
    input [2:0] workModeMux,

    input [7:0] SxBuildAuxPwr,
    input [7:0] SxNormalOn,
    input [7:0] SxPwrOffStage1,
    input [7:0] SxPwrOffStage2,
    
    output S1,
    output S2,
    output S3,
    output S4,
    output S5,
    output S6,
    output S7,
    output S8
);
 
reg [7:0]reg_Sx ;

always@(posedge clk or negedge rst_n) begin 
    if(rst_n == 1'b0)begin
        reg_Sx <= 8'd0;
    end
    else begin
        case (workModeMux)
            // -----------------------------------------------------------
            `DAB_MODE_PRI_BOOTSTRAP,
            `DAB_MODE_BUILD_AUX_PWR: begin
                reg_Sx <= SxBuildAuxPwr;  // SxBuildAuxPwr里面包含了自举和原边高频脉冲
            end
            
            // -----------------------------------------------------------
            `DAB_MODE_SEC_BOOTSTRAP: begin
                reg_Sx <= {1'd0, 		// S8
                           1'd1,        // S7
                           1'd1,        // S6
                           1'd0,        // S5
                           4'd0};       // S1~S4 OFF
            end

            // -----------------------------------------------------------
            `DAB_MODE_NORMAL_ON: begin
                reg_Sx <= SxNormalOn;
                //reg_Sx <= 8'd0;
            end

            // -----------------------------------------------------------
            `DAB_MODE_NORMAL_OFF: begin
                reg_Sx <= SxPwrOffStage1;
            end

            // -----------------------------------------------------------
            `DAB_MODE_S67_FREE_WHEEL: begin
                reg_Sx <= SxPwrOffStage2;
            end

            // -----------------------------------------------------------
            `DAB_MODE_ALL_DRV_OFF: begin
                reg_Sx <= 8'd0;
            end

            // -----------------------------------------------------------
            default: begin
                reg_Sx <= 8'd0;
            end
        endcase 
    end
end

assign S1 = reg_Sx[0];
assign S2 = reg_Sx[1];
assign S3 = reg_Sx[2];
assign S4 = reg_Sx[3];
assign S5 = reg_Sx[4];
assign S6 = reg_Sx[5];
assign S7 = reg_Sx[6];
assign S8 = reg_Sx[7];

endmodule
