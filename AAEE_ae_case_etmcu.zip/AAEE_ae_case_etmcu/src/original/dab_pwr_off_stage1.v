`include "common.vh"

module DAB_PWR_OFF_STAGE1
(
    input       clk, 
    input rst_n,
    input [2:0] workModeMux,
    input       vgIsPos,
    input       vgIsNeg,

    input S5Mux,
    input S6Mux,
    input S7Mux,
    input S8Mux,

    output [7:0] Sx
);

reg reg_S5;
reg reg_S6;
reg reg_S7;
reg reg_S8;
//reg reg_debugOut = 0;

always@(posedge clk or negedge rst_n) begin
    if(rst_n == 1'b0)begin
        reg_S5 <= 1'd0;
        reg_S6 <= 1'd0;
        reg_S7 <= 1'd0;
        reg_S8 <= 1'd0;
    end
    else if(workModeMux != `DAB_MODE_NORMAL_OFF) begin
        reg_S5 <= S5Mux;
        reg_S6 <= S6Mux;
        reg_S7 <= S7Mux;
        reg_S8 <= S8Mux;
    end
    else begin
        if (vgIsPos) begin
            reg_S5 <= 0;
            reg_S6 <= 1;
            reg_S7 <= 0;
            reg_S8 <= 1;
        end 
        else if(vgIsNeg) begin 
            reg_S5 <= 1;
            reg_S6 <= 0;
            reg_S7 <= 1;
            reg_S8 <= 0;
        end
        else begin
            reg_S5 <= 0;
            reg_S6 <= 1;
            reg_S7 <= 1;
            reg_S8 <= 0;
        end
    end
end

wire wire_S5out;
wire wire_S6out;
wire wire_S7out;
wire wire_S8out;

pwm_db_v2 PWM_DB5
(
    .clk(clk),
    .rst_n(rst_n),
	.pwmDb(`PWR_OFF_STAGE1_DB),
    .pwmIn(reg_S5),
    .pwmOut(wire_S5out)
);

pwm_db_v2 PWM_DB6
(
    .clk(clk),
    .rst_n(rst_n),
    .pwmDb(`PWR_OFF_STAGE1_DB),
    .pwmIn(reg_S6),
    .pwmOut(wire_S6out)
);

pwm_db_v2 PWM_DB7
(
    .clk(clk),
    .rst_n(rst_n),
    .pwmDb(`PWR_OFF_STAGE1_DB),
    .pwmIn(reg_S7),
    .pwmOut(wire_S7out)
);

pwm_db_v2 PWM_DB8
(
    .clk(clk),
    .rst_n(rst_n),
    .pwmDb(`PWR_OFF_STAGE1_DB),
    .pwmIn(reg_S8),
    .pwmOut(wire_S8out)
);

assign Sx = {wire_S8out, 
             wire_S7out,
             wire_S6out,
             wire_S5out,
             4'd0};        // S1~S4 OFF

endmodule
