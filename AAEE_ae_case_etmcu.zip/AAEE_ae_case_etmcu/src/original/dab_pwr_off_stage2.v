`include "common.vh"

module DAB_PWR_OFF_STAGE2    // DAB副边续流
(
    input       clk, 
    input rst_n,
    input [2:0] workModeMux,
    input       vgIsPos,
    input       vgIsNeg,

    input S5Mux,
    input S6Mux,
    input S7Mux,
    input S8Mux,

    output [7:0] Sx,
    output debugOut
);

localparam [5:0] DELAY_THRESH = 45;
reg        [5:0] reg_delayCnt = DELAY_THRESH + 1;

reg reg_vgIsPos;
reg reg_vgIsNeg;

reg reg_S5;
reg reg_S6;
reg reg_S7;
reg reg_S8;
reg reg_debugOut ;

always@(posedge clk or negedge rst_n) begin
    if(rst_n == 1'b0)begin
        reg_S5 <= 1'd0;
        reg_S6 <= 1'd0;
        reg_S7 <= 1'd0;
        reg_S8 <= 1'd0;
        reg_debugOut <= 1'd0;
    end
    else if(workModeMux != `DAB_MODE_S67_FREE_WHEEL) begin
        reg_delayCnt <= 0;
        reg_vgIsPos  <= vgIsPos;      // 锁存vgIsPos/Neg，防止插入时序乱跳
        reg_vgIsNeg  <= vgIsNeg;    // 锁存vgIsPos/Neg，防止插入时序乱跳

        reg_S5 <= S5Mux;
        reg_S6 <= S6Mux;
        reg_S7 <= S7Mux;
        reg_S8 <= S8Mux;
        
        reg_debugOut <= !reg_debugOut;
    end
    else begin
        // 更新延时计数器
        if (reg_delayCnt < DELAY_THRESH) begin 
            reg_delayCnt <= reg_delayCnt + 1;
        end

        // 更新副边发波
        if(reg_delayCnt < DELAY_THRESH) begin 
            // 在插入时序时间内，根据电网电压符号S8/S5额外导通一段时间
            if (reg_vgIsPos) begin
                reg_S5 <= 0;
                reg_S6 <= 1;
                reg_S7 <= 1;
                reg_S8 <= 1;
            end 
            else if(reg_vgIsNeg) begin 
                reg_S5 <= 1;
                reg_S6 <= 1;
                reg_S7 <= 1;
                reg_S8 <= 0;
            end
            else begin
                reg_S5 <= 0;
                reg_S6 <= 1;
                reg_S7 <= 1;
                reg_S8 <= 0;
            end

            reg_debugOut <= 1;
        end 
        else begin 
            // 插入时序结束后，固定S6，S7导通
            reg_S5 <= 0;
            reg_S6 <= 1;
            reg_S7 <= 1;
            reg_S8 <= 0;
            
            reg_debugOut <= 0;
        end
    end
end

wire wire_S5out;
wire wire_S6out;
wire wire_S7out;
wire wire_S8out;

pwm_db_v2 PWM_DB5
(
    .clk(clk),
    .rst_n(rst_n),
    .pwmDb(`PWR_OFF_STAGE2_DB),
    .pwmIn(reg_S5),
    .pwmOut(wire_S5out)
);

pwm_db_v2 PWM_DB6
(
    .clk(clk),
    .rst_n(rst_n),
    .pwmDb(`PWR_OFF_STAGE2_DB),
    .pwmIn(reg_S6),
    .pwmOut(wire_S6out)
);

pwm_db_v2 PWM_DB7
(
    .clk(clk),
    .rst_n(rst_n),
    .pwmDb(`PWR_OFF_STAGE2_DB),
    .pwmIn(reg_S7),
    .pwmOut(wire_S7out)
);

pwm_db_v2 PWM_DB8
(
    .clk(clk),
    .rst_n(rst_n),
    .pwmDb(`PWR_OFF_STAGE2_DB),
    .pwmIn(reg_S8),
    .pwmOut(wire_S8out)
);

assign Sx = {wire_S8out, 
             wire_S7out,
             wire_S6out,
             wire_S5out,
             4'd0};        // S1~S4 OFF

assign debugOut = reg_debugOut;

endmodule
