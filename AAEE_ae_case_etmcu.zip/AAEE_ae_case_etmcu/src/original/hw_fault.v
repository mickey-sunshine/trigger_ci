module HW_FAULT
(
    input  clk, 
    input rst_n,

    input  UNLOCK_FAULT,
    input  ICT_OC,
    input  INV_OC,
    input  CPLD_XOR_FAIL,
    input  vgCmpFail,
    input  itCmpFail,
    input  secDrvShort,
    input  fsmFail,
    input  INV_OV,
    input  PV_OV,
    
    output ictOcOst,
    output invOcOst,
    output xorFailOst,
    output fsmFailOst,
    output vgCmpFailOst,
    output itCmpFailOst,
    output secDrvShortOst,
    output invOvOst,
    output pvOvOst,

    output hasFault
);

wire wire_ictOcOst;
wire wire_invOcOst;
wire wire_xorFailOst;
wire wire_fsmFailOst;
wire wire_vgCmpFailOst;
wire wire_itCmpFailOst;
wire wire_secDrvShortOst;
wire wire_invOvOst;
wire wire_pvOvOst;

tz_ost U101
(
    .clk    (clk), 
    .rst_n(rst_n),
    .tzSet  (ICT_OC),
    .tzClr  (UNLOCK_FAULT),
    .tzLatch(wire_ictOcOst)
);

tz_ost U102
(
    .clk    (clk), 
    .rst_n(rst_n),
    .tzSet  (INV_OC),
    .tzClr  (UNLOCK_FAULT),
    .tzLatch(wire_invOcOst)
);

tz_ost U103
(
    .clk    (clk), 
    .rst_n(rst_n),
    .tzSet  (CPLD_XOR_FAIL),
    .tzClr  (UNLOCK_FAULT),
    .tzLatch(wire_xorFailOst)
);


tz_ost U104
(
    .clk    (clk), 
    .rst_n(rst_n),
    .tzSet  (vgCmpFail),
    .tzClr  (UNLOCK_FAULT),
    .tzLatch(wire_vgCmpFailOst)
);

tz_ost U105
(
    .clk    (clk), 
    .rst_n(rst_n),
    .tzSet  (itCmpFail),
    .tzClr  (UNLOCK_FAULT),
    .tzLatch(wire_itCmpFailOst)
);

tz_ost U106
(
    .clk    (clk), 
    .rst_n(rst_n),
    .tzSet  (secDrvShort),
    .tzClr  (UNLOCK_FAULT),
    .tzLatch(wire_secDrvShortOst)
);

tz_ost U107
(
    .clk    (clk), 
    .rst_n(rst_n),
    .tzSet  (fsmFail),
    .tzClr  (UNLOCK_FAULT),
    .tzLatch(wire_fsmFailOst)
);

tz_ost U108
(
    .clk    (clk), 
    .rst_n(rst_n),
    .tzSet  (INV_OV),
    .tzClr  (UNLOCK_FAULT),
    .tzLatch(wire_invOvOst)
);

tz_ost U109
(
    .clk    (clk), 
    .rst_n(rst_n),
    .tzSet  (PV_OV),
    .tzClr  (UNLOCK_FAULT),
    .tzLatch(wire_pvOvOst)
);

assign ictOcOst       = wire_ictOcOst;
assign invOcOst       = wire_invOcOst;
assign xorFailOst     = wire_xorFailOst;
assign vgCmpFailOst   = wire_vgCmpFailOst;
assign itCmpFailOst   = wire_itCmpFailOst;
assign secDrvShortOst = wire_secDrvShortOst;
assign fsmFailOst     = wire_fsmFailOst;
assign invOvOst       = wire_invOvOst;
assign pvOvOst        = wire_pvOvOst;
assign hasFault       = wire_fsmFailOst | wire_ictOcOst | wire_invOcOst | wire_xorFailOst | wire_vgCmpFailOst | wire_itCmpFailOst | wire_secDrvShortOst | wire_invOvOst | wire_pvOvOst;

endmodule
