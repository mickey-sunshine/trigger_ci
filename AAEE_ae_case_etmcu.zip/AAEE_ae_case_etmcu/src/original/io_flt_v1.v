module IO_FLT_V1
#(
    parameter [5:0] FLT_NUM = 10
)
(
    input  clk,
    input rst_n,
    input  in,
    output out
);

localparam [5:0] TIMER_MAX = 6'd63;

reg [5:0]reg_timer;
reg reg_out;

//initial begin
//    reg_timer <= 6'd0;
//    reg_out   <= 1'd0;
//end

always@(posedge clk or negedge rst_n) begin
    if(rst_n == 1'b0)begin
        reg_timer <= 6'd0;
        reg_out   <= 1'd0;
    end
    else if(reg_out) begin
        if(in) begin
            reg_timer <= 0;
        end
        else begin            
            if(reg_timer >= FLT_NUM) begin
                reg_out   <= 0;
                reg_timer <= 0;
            end
            else begin
                if (reg_timer < TIMER_MAX) begin
                    reg_timer <= reg_timer + 6'd1; 
                end                
            end
        end
    end
    else begin
        if(!in) begin
            reg_timer <= 0;
        end
        else begin
            if(reg_timer >= FLT_NUM) begin
                reg_out   <= 1;
                reg_timer <= 0;
            end
            else begin
                if (reg_timer < TIMER_MAX) begin
                    reg_timer <= reg_timer + 6'd1; 
                end                
            end
        end
    end
end

assign out = reg_out;

endmodule
