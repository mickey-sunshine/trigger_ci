`include "common.vh"

module pwm_db_v1
(
    input  clk,
    input rst_n,
    input [`DB_REG_WIDTH - 1 : 0] pwmDb,
    input  pwm0,
    output pwmH,
    output pwmL
);

// ----------------------------------------------------------------------------
reg [`DB_REG_WIDTH - 1 : 0] regP1_pwmDb  ;
reg [`DB_REG_WIDTH - 1 : 0] regP1_dbCnt ;
reg regP1_pwm0 ;

always@(posedge clk or negedge rst_n) begin
    if(rst_n == 1'b0)begin
        regP1_pwm0 <= 1'b0;
    end
    else begin
        regP1_pwm0 <= pwm0;
    end
end

always@(posedge clk or negedge rst_n) begin
    if(rst_n == 1'b0)begin
        regP1_dbCnt <= 'd0;
        regP1_pwmDb <= `PWM_DB_MIN;
    end
    else if(regP1_pwm0 != pwm0) begin
        regP1_dbCnt <= 0;
        regP1_pwmDb <= pwmDb;
    end
    else begin
        if (regP1_dbCnt < `DB_REG_MAX) begin
			regP1_dbCnt <= regP1_dbCnt + 1; 
    	end
    end
end

// ----------------------------------------------------------------------------
reg regP2_pwmH ;
reg regP2_pwmL ;

always@(posedge clk or negedge rst_n) begin
    if(rst_n == 1'b0)begin
        regP2_pwmH <= 0;
        regP2_pwmL <= 0;
    end
    else if(regP1_pwm0) begin
        regP2_pwmH <= (regP1_dbCnt >= regP1_pwmDb) ? 1 : 0;
        regP2_pwmL <= 0;
    end
    else begin
        regP2_pwmH <= 0;
        regP2_pwmL <= (regP1_dbCnt >= regP1_pwmDb) ? 1 : 0;
    end
end

// ----------------------------------------------------------------------------
assign pwmH = regP2_pwmH;
assign pwmL = regP2_pwmL;

endmodule
