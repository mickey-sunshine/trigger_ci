`include "common.vh"

module pwm_db_v2
(
    input  clk,
    input rst_n,
    input [`DB_REG_WIDTH - 1 : 0] pwmDb,
    input  pwmIn,
    output pwmOut
);

reg [`DB_REG_WIDTH : 0] reg_dbCtr ;
reg reg_pwmOut;

always@(posedge clk or negedge rst_n) begin
    if(rst_n == 1'b0)begin
         reg_dbCtr <= 0; 
         reg_pwmOut <= 0;
    end
    else if(pwmIn) begin
        if (reg_dbCtr < pwmDb) begin
            reg_dbCtr <= reg_dbCtr + 1; 
            reg_pwmOut <= 0;
        end
        else begin
            reg_pwmOut <= 1;
        end
    end
    else begin
        reg_dbCtr  <= 0;
        reg_pwmOut <= 0;
    end
end

assign pwmOut = reg_pwmOut;

endmodule
