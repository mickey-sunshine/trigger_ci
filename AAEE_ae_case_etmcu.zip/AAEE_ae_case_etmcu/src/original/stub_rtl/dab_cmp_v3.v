`include "common.vh"

module dab_cmp_v3
(
    input clk,
    input rst_n,

    input rstN,
    input [`CMP_REG_WIDTH - 1 : 0] pwmPrd,
    input [`CMP_REG_WIDTH - 1 : 0] cmpPriOnB,
    input [`CMP_REG_WIDTH - 1 : 0] cmpSecOnA,
    input [`CMP_REG_WIDTH - 1 : 0] cmpSecOnB,
    
    output [`CMP_REG_WIDTH - 1 : 0] pwmCnt,
    output [`CMP_REG_WIDTH - 1 : 0] cmpPriPwm0A_On,
    output [`CMP_REG_WIDTH - 1 : 0] cmpPriPwm0A_Off,
    output [`CMP_REG_WIDTH - 1 : 0] cmpPriPwm0B_On,
    output [`CMP_REG_WIDTH - 1 : 0] cmpPriPwm0B_Off,
    output [`CMP_REG_WIDTH - 1 : 0] cmpSecPwm0A_On,
    output [`CMP_REG_WIDTH - 1 : 0] cmpSecPwm0A_Off,
    output [`CMP_REG_WIDTH - 1 : 0] cmpSecPwm0B_On,
    output [`CMP_REG_WIDTH - 1 : 0] cmpSecPwm0B_Off,
    
    output trigOut
);

// ----------------------------------------------------------------------------
//  第1级流水线，参数限幅
reg [`CMP_REG_WIDTH - 1 : 0] regP1_pwmPrd ;
reg [`CMP_REG_WIDTH - 1 : 0] regP1_pwmPrdHalf ;
reg [`CMP_REG_WIDTH - 1 : 0] regP1_cmpPriOnB ;
//reg [`CMP_REG_WIDTH - 1 : 0] regP1_cmpSecOnA ;
//reg [`CMP_REG_WIDTH - 1 : 0] regP1_cmpSecOnB ;

//always@(posedge clk or negedge rst_n) begin 
//    if(rst_n == 1'b0)begin
//        regP1_pwmPrd <= `PWM_PRD_MIN;
//        regP1_pwmPrdHalf <= `PWM_PRD_MIN >> 1;
//    end
//    else if(pwmPrd < `PWM_PRD_MIN)begin
//        regP1_pwmPrd <= `PWM_PRD_MIN;
//        regP1_pwmPrdHalf <= `PWM_PRD_MIN >> 1;
//    end
//    else if(pwmPrd > `PWM_PRD_MAX)begin
//        regP1_pwmPrd <= `PWM_PRD_MAX;
//        regP1_pwmPrdHalf <= `PWM_PRD_MAX >> 1;
//    end
//    else begin
//        regP1_pwmPrd <= pwmPrd;
//        regP1_pwmPrdHalf <= pwmPrd >> 1;
//    end
//    
//end

always@(*) begin 
    if(pwmPrd < `PWM_PRD_MIN)begin
        regP1_pwmPrd <= `PWM_PRD_MIN;
        regP1_pwmPrdHalf <= `PWM_PRD_MIN >> 1;
    end
    else if(pwmPrd > `PWM_PRD_MAX)begin
        regP1_pwmPrd <= `PWM_PRD_MAX;
        regP1_pwmPrdHalf <= `PWM_PRD_MAX >> 1;
    end
    else begin
        regP1_pwmPrd <= pwmPrd;
        regP1_pwmPrdHalf <= pwmPrd >> 1;
    end
    
end

//always@(posedge clk or negedge rst_n) begin 
//    if(rst_n == 1'b0)begin
//        regP1_cmpPriOnB <= 'd0;
//        regP1_cmpSecOnA <= 'd0;
//        regP1_cmpSecOnB <= 'd0;
//    end
//    else begin
//        regP1_cmpPriOnB <= cmpPriOnB;
//        regP1_cmpSecOnA <= cmpSecOnA;
//        regP1_cmpSecOnB <= cmpSecOnB;
//    end
//end

always@(*) begin 
        regP1_cmpPriOnB <= cmpPriOnB;
//        regP1_cmpSecOnA <= cmpSecOnA;
//        regP1_cmpSecOnB <= cmpSecOnB;
end

// ----------------------------------------------------------------------------
reg [`CMP_REG_WIDTH - 1 : 0] regP2_pwmPrd                   ;
reg [`CMP_REG_WIDTH - 1 : 0] regP2_pwmCnt        ;

reg [`CMP_REG_WIDTH - 1 : 0] regP2_cmpPriPwm0B_On ;
//reg [`CMP_REG_WIDTH - 1 : 0] regP2_cmpSecPwm0A_On ;
//reg [`CMP_REG_WIDTH - 1 : 0] regP2_cmpSecPwm0B_On ;

reg [`CMP_REG_WIDTH - 1 : 0] regP2_cmpPriPwm0A_Off ;
reg [`CMP_REG_WIDTH - 1 : 0] regP2_cmpPriPwm0B_Off ;
//reg [`CMP_REG_WIDTH - 1 : 0] regP2_cmpSecPwm0A_Off ;
//reg [`CMP_REG_WIDTH - 1 : 0] regP2_cmpSecPwm0B_Off ;

always@(posedge clk or negedge rst_n) begin 
    if(rst_n == 1'b0)begin
        regP2_pwmCnt <= 0;
        regP2_pwmPrd <= `PWM_PRD_MIN;
        regP2_cmpPriPwm0B_On <= 'd0;
//        regP2_cmpSecPwm0A_On <= 'd0;
//        regP2_cmpSecPwm0B_On <= 'd0;
        regP2_cmpPriPwm0A_Off <= 'd0;
        regP2_cmpPriPwm0B_Off <= 'd0;
//        regP2_cmpSecPwm0A_Off <= 'd0;
//        regP2_cmpSecPwm0B_Off <= 'd0;
    end
    else if ((regP2_pwmCnt + 1 < regP2_pwmPrd) && rstN) begin 
        regP2_pwmCnt <= regP2_pwmCnt + 1;
    end
    else begin 
        regP2_pwmCnt <= 0;
        regP2_pwmPrd <= regP1_pwmPrd;
        
        regP2_cmpPriPwm0B_On <= regP1_cmpPriOnB;
//        regP2_cmpSecPwm0A_On <= regP1_cmpSecOnA;
//        regP2_cmpSecPwm0B_On <= regP1_cmpSecOnB;

        regP2_cmpPriPwm0A_Off <= regP1_pwmPrdHalf;
        regP2_cmpPriPwm0B_Off <= (regP1_cmpPriOnB < regP1_pwmPrdHalf) 
                               ? (regP1_cmpPriOnB + regP1_pwmPrdHalf)
                               : (regP1_cmpPriOnB - regP1_pwmPrdHalf);
                               
//        regP2_cmpSecPwm0A_Off <= (regP1_cmpSecOnA < regP1_pwmPrdHalf) 
//                               ? (regP1_cmpSecOnA + regP1_pwmPrdHalf)
//                               : (regP1_cmpSecOnA - regP1_pwmPrdHalf);
//
//        regP2_cmpSecPwm0B_Off <= (regP1_cmpSecOnB < regP1_pwmPrdHalf) 
//                               ? (regP1_cmpSecOnB + regP1_pwmPrdHalf)
//                               : (regP1_cmpSecOnB - regP1_pwmPrdHalf);
    end
end


// ----------------------------------------------------------------------------
//reg [5 : 0] regP3_trigDiv ;
//reg regP3_trigOutRaw ;

//always@(posedge clk or negedge rst_n) begin 
//    if(rst_n == 1'b0)begin
//		regP3_trigDiv <= 'd0;
//    end
//	else if(regP2_pwmPrd <= `TRIG_OUT_DIV20_PRD) begin
//		regP3_trigDiv <= 20;
//    end 
//    else if(regP2_pwmPrd <= `TRIG_OUT_DIV10_PRD) begin
//		regP3_trigDiv <= 10;
//    end
//	else if(regP2_pwmPrd <= `TRIG_OUT_DIV5_PRD) begin
//		regP3_trigDiv <= 5;
//    end
//	else if(regP2_pwmPrd <= `TRIG_OUT_DIV4_PRD) begin
//		regP3_trigDiv <= 4;
//    end
//    else if(regP2_pwmPrd <= `TRIG_OUT_DIV3_PRD) begin
//		regP3_trigDiv <= 3;
//    end
//	else if(regP2_pwmPrd <= `TRIG_OUT_DIV2_PRD) begin
//		regP3_trigDiv <= 2;
//    end
//	else begin
//		regP3_trigDiv <= 1;
//    end
//end

//always@(posedge clk or negedge rst_n) begin 
//    if(rst_n == 1'b0)begin
//		regP3_trigOutRaw <= 0;
//    end
//	// 产生原始触发信号
//	else if(regP2_pwmCnt < (`PWM_PRD_MIN >> 1)) begin
//		regP3_trigOutRaw <= 0;
//    end
//	else if(regP2_pwmCnt + `TRIG_OUT_PHASE_LEAD >= regP2_pwmPrd) begin
//    	regP3_trigOutRaw <= 1;
//    end
//    else begin
//		regP3_trigOutRaw <= 0;
//    end
//end

//TRIG_DIV TRIG_OUT_DIV
//(
//	.clk(clk),
//    .rst_n(rst_n),
//    .trigIn(regP3_trigOutRaw),
//	.trigDiv(regP3_trigDiv),
//    .trigOut(trigOut)
//);

assign trigOut = 0;

// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
assign pwmCnt = regP2_pwmCnt;

assign cmpPriPwm0A_On  = 0;
assign cmpPriPwm0A_Off = regP2_cmpPriPwm0A_Off;

assign cmpPriPwm0B_On  = regP2_cmpPriPwm0B_On;
assign cmpPriPwm0B_Off = regP2_cmpPriPwm0B_Off;

//assign cmpSecPwm0A_On  = regP2_cmpSecPwm0A_On;
//assign cmpSecPwm0A_Off = regP2_cmpSecPwm0A_Off;

//assign cmpSecPwm0B_On  = regP2_cmpSecPwm0B_On;
//assign cmpSecPwm0B_Off = regP2_cmpSecPwm0B_Off;

assign cmpSecPwm0A_On  = 0;
assign cmpSecPwm0A_Off = 0;

assign cmpSecPwm0B_On  = 0;
assign cmpSecPwm0B_Off = 0;
endmodule
