module DAB_EPS_V3 (
    clk,
    rst_n,
    workModeMux,
    priPwmDb,
    secPwmDb,
    pwmPrd,
    cmpPriOnB,
    cmpSecOnA,
    vgIsPos,
    vgIsNeg,
    itIsPos,
    itIsNeg,
    Sx,
    trigOut
);



input clk;
input rst_n;
input [2:0] workModeMux;
input [`DB_REG_WIDTH - 1 : 0] priPwmDb;
input [`DB_REG_WIDTH - 1 : 0] secPwmDb;
input [`CMP_REG_WIDTH - 1 : 0] pwmPrd;
input [`CMP_REG_WIDTH - 1 : 0] cmpPriOnB;
input [`CMP_REG_WIDTH - 1 : 0] cmpSecOnA;
input vgIsPos;
input vgIsNeg;
input itIsPos;
input itIsNeg;




output [7:0]Sx;
output trigOut;


wire   [7:0]Sx;
wire   trigOut;


assign Sx = 'b0;
assign trigOut = 'b0;


endmodule