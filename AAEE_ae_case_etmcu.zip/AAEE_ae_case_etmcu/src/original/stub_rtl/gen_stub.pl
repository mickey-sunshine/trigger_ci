system("rm -rf stub_*.v stub_*.sv");

@array_file1 = glob("*.sv");
@array_file2 = glob("*.v");
@array_file = (@array_file1,@array_file2 );

for my $i (0..$#array_file) {
    $file_name = $array_file[$i];
    open(FILE,"$file_name") or warn "$file_name not exists\n";
    @array_rtl = <FILE>;
    close(FILE );
    open(SAVE_FILE,">stub_$file_name") or warn "create stub_$file_name failed\n";

    @inputs = ();
    @outputs = ();
    @inouts = ();
    @ports = ();
    @parameters_defines = ();
    %hash_output_stub = {};
    $para_def_flag = 0;
    for my $j (0..$#array_rtl ) {
        $rtl_line = $array_rtl[$j];

        #### one line param / define
        if(($rtl_line =~ m/^\s*parameter\b/ || $rtl_line =~ m/^\s*`define\b/) && ($rtl_line =~ m/;/ || $rtl_line =~ m/\)/)) {
            push(@parameters_defines,"$rtl_line");
            #print("one line!\n $rtl_line\n");
        }

        #### multi line param / define
        ### find first line
        if(($rtl_line =~ m/^\s*parameter\b/ || $rtl_line =~ m/^\s*`define\b/) && ($rtl_line !~ m/;/) && $rtl_line !~ m/\)/) {
            $para_def_flag = 1;
            chomp($rtl_line);
            #print("first line!\n $rtl_line\n");
        }

        ### find last line
        if($para_def_flag == 1 && ($rtl_line =~ m/;/ || $rtl_line =~ m/\)/)) {
            $para_def_flag = 0;
            #chomp($rtl_line);
            #print("last line!\n $rtl_line\n");
            if ($rtl_line =~ m/^\)/) { 
                $rtl_line =~ s/\)/\;/g;
                #print("last line-2!\n $rtl_line\n");
                push(@parameters_defines,"$rtl_line");
                #print("all para!\n @parameters_defines\n");
            } 
        } elsif($para_def_flag == 1) {
            chomp($rtl_line);
            push(@parameters_defines,"$rtl_line\n");
        }

        $rtl_line =~ s/^\s+//g;
        $rtl_line =~ s/,/;/g;
        $rtl_line =~ s/$/;/;
        $rtl_line =~ s/;\s*;/;/;
        $rtl_line =~ s/;\s*;/;/;
        $rtl_line =~ s/;\s*;/;/;
        if($rtl_line =~ m/(\w+)\s*[,;]\s*\/\/\s*STUB\s*\[(.*)\]/) {
            $key = $1;
            $value = $2;
            $value =~ s/\s+//g;
            $hash_output_stub{$key} = $value;
            print "#0 $key $value $hash_output_stub{$key} $rtl_line";
        }

        $rtl_line =~ s/\/\/.*//;
        if($rtl_line =~ m/module\s+(\w+)/) {
            $module_name = $1;
        }

        #if($rtl_line =~ m/^\s*parameter\b/ || $rtl_line =~ m/^\s*`define\b/) {
        #    $rtl_line =~ s/,\s*$//;
        #    $rtl_line =~ s/$/;/;
        #    $rtl_line =~ s/;\s*;/;/;
        #    $rtl_line =~ s/\r//;

        #    #print "$rtl_line";
        #    push(@parameters_defines,"$rtl_line\n");
        #}

        if($rtl_line =~ m/^\s*input\b/) {
            $rtl_line =~ s/\bwire\b//;
            $rtl_line =~ s/\breg\b//;
            push(@inputs,$rtl_line);
            push(@ports,$rtl_line);
        }

        if($rtl_line =~ m/^\s*inout\b/) {
            $rtl_line =~ s/\bwire\b//;
            $rtl_line =~ s/\breg\b//;
            push(@inouts,$rtl_line);
            push(@ports,$rtl_line);
        }

        if($rtl_line =~ m/^\s*output\b/) {
            $rtl_line =~ s/\bwire\b//;
            $rtl_line =~ s/\breg\b//;
            push(@outputs,$rtl_line);
            push(@ports,$rtl_line);
        }

        if($rtl_line =~ m/^\s*reg\b/ || $rtl_line =~ m/^\s*wire\b/) {
            last;
        }
    }

    #gen new stub file;
    print SAVE_FILE "module $module_name (\n";

    for my $j (0..$#inputs) {
        $tmp = $inputs[$j]; 
        $tmp =~ s/\[.*\]//;
        $tmp =~ s/^\s*input\b//;
        $tmp =~ s/\s+//g;
        $tmp =~ s/;//g;
        print SAVE_FILE "    $tmp,\n";
    }

    for my $j (0..$#inouts) {
        $tmp = $inouts[$j];
        $tmp =~ s/\[.*\]//;
        $tmp =~ s/^\s*inout\b//;
        $tmp =~ s/\s+//g;
        $tmp =~ s/;//g;
        print SAVE_FILE "    $tmp,\n";
    }

    for my $j (0..$#outputs-1) {
        $tmp = $outputs[$j];
        $tmp =~ s/\[.*\]//;
        $tmp =~ s/^\s*output\b//;
        $tmp =~ s/\s+//g;
        $tmp =~ s/;//g;
        print SAVE_FILE "    $tmp,\n";
    }

    $tmp = $outputs[$#outputs];
    $tmp =~ s/\[.*\]//;
    $tmp =~ s/^\s*output\b//;
    $tmp =~ s/\s+//g;
    $tmp =~ s/;//g;
    
    print SAVE_FILE "    $tmp\n";
    print SAVE_FILE ");\n\n";


    for my $j (0..$#parameters_defines)  {
        $tmp = $parameters_defines[$j];
        print SAVE_FILE "$tmp";
    }
    print SAVE_FILE "\n\n";

    for my $j (0..$#inputs) {
        $tmp = $inputs[$j]; 
        $tmp =~ s/$/;/;
        $tmp =~ s/;\s*;/;/;
        print SAVE_FILE "$tmp";
    }
    print SAVE_FILE "\n\n";

    for my $j (0..$#inouts) {
        $tmp = $inouts[$j];
        $tmp =~ s/$/;/;
        $tmp =~ s/;\s*;/;/;
        print SAVE_FILE "$tmp";
    }
    print SAVE_FILE "\n\n";

    for my $j (0..$#outputs) {
        $tmp = $outputs[$j];
        $tmp =~ s/$/;/;
        $tmp =~ s/;\s*;/;/;
        print SAVE_FILE "$tmp";
    }
    print SAVE_FILE "\n\n";



    for my $j (0..$#outputs) {
        $tmp = $outputs[$j];
        $tmp =~ s/output/wire  /;
        $tmp =~ s/$/;/;
        $tmp =~ s/;\s*;/;/;
        print SAVE_FILE "$tmp";
    }
    print SAVE_FILE "\n\n";


    for my $j (0..$#outputs) {
        $tmp = $outputs[$j];
        chomp($tmp);
        $tmp =~ s/output//;
        $tmp =~ s/\[.*\]//;
        $tmp =~ s/;//;
        $tmp =~ s/\s+//g;
        if(exists $hash_output_stub{$tmp}) {
            print SAVE_FILE "assign $tmp = $hash_output_stub{$tmp};\n";
        }elsif($tmp =~ m/ready/i) {
            print SAVE_FILE "assign $tmp = 'b1;\n";
        }elsif($tmp =~ m/_rdy/i) {
            print SAVE_FILE "assign $tmp = 'b1;\n";
        }elsif($tmp =~ m/oe_n/i) {
            print SAVE_FILE "assign $tmp = 'b1;\n";
        }elsif($tmp =~ m/uart.*_txd/i || $tmp =~ m/can.*_txd/i) {
            print SAVE_FILE "assign $tmp = 'b1;\n";
        }else {
            print SAVE_FILE "assign $tmp = 'b0;\n";
        }
    }


    print SAVE_FILE "\n\nendmodule";
    close(SAVE_FILE );

        #    $csv_file_name = $file_name;
        #    $csv_file_name =~ s/\.s?v/.csv/;
        #    open(SAVE2_FILE,">$csv_file_name" ) or warn "$csv_file_name create failed\n";
        #
        #    print SAVE2_FILE "NAME,WIDTH,DIRECTRION,From/To,Comments\n";
        #    for my $j (0..$#ports ) {
        #        $tmp = $ports[$j];
        #        chomp($tmp);
        #        if($tmp =~ m/^\s*(\w+)\s*(\[.*\])\s*(\w+)/) {
        #            $direction = $1;
        #            $width_string = $2;
        #            $name = $3;
        #            $width_string =~ s/\s+//g;
        #            print SAVE2_FILE "$name,$width_string,$direction,,,\n";
        #        }elsif($tmp =~ m/^\s*(\w+)\s*(\w+)/) {
        #            $direction = $1;
        #            $width_string = "1";
        #            $name = $2;
        #            $width_string =~ s/\s+//g;
        #            print SAVE2_FILE "$name,$width_string,$direction,,,\n";
        #        }
        #    }
        #    close(SAVE2_FILE);
        #
}

