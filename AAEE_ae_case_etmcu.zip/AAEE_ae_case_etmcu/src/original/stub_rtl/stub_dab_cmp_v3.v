module dab_cmp_v3 (
    clk,
    rst_n,
    rstN,
    pwmPrd,
    cmpPriOnB,
    cmpSecOnA,
    cmpSecOnB,
    pwmCnt,
    cmpPriPwm0A_On,
    cmpPriPwm0A_Off,
    cmpPriPwm0B_On,
    cmpPriPwm0B_Off,
    cmpSecPwm0A_On,
    cmpSecPwm0A_Off,
    cmpSecPwm0B_On,
    cmpSecPwm0B_Off,
    trigOut
);



input clk;
input rst_n;
input rstN;
input [`CMP_REG_WIDTH - 1 : 0] pwmPrd;
input [`CMP_REG_WIDTH - 1 : 0] cmpPriOnB;
input [`CMP_REG_WIDTH - 1 : 0] cmpSecOnA;
input [`CMP_REG_WIDTH - 1 : 0] cmpSecOnB;




output [`CMP_REG_WIDTH - 1 : 0] pwmCnt;
output [`CMP_REG_WIDTH - 1 : 0] cmpPriPwm0A_On;
output [`CMP_REG_WIDTH - 1 : 0] cmpPriPwm0A_Off;
output [`CMP_REG_WIDTH - 1 : 0] cmpPriPwm0B_On;
output [`CMP_REG_WIDTH - 1 : 0] cmpPriPwm0B_Off;
output [`CMP_REG_WIDTH - 1 : 0] cmpSecPwm0A_On;
output [`CMP_REG_WIDTH - 1 : 0] cmpSecPwm0A_Off;
output [`CMP_REG_WIDTH - 1 : 0] cmpSecPwm0B_On;
output [`CMP_REG_WIDTH - 1 : 0] cmpSecPwm0B_Off;
output trigOut;


wire   [`CMP_REG_WIDTH - 1 : 0] pwmCnt;
wire   [`CMP_REG_WIDTH - 1 : 0] cmpPriPwm0A_On;
wire   [`CMP_REG_WIDTH - 1 : 0] cmpPriPwm0A_Off;
wire   [`CMP_REG_WIDTH - 1 : 0] cmpPriPwm0B_On;
wire   [`CMP_REG_WIDTH - 1 : 0] cmpPriPwm0B_Off;
wire   [`CMP_REG_WIDTH - 1 : 0] cmpSecPwm0A_On;
wire   [`CMP_REG_WIDTH - 1 : 0] cmpSecPwm0A_Off;
wire   [`CMP_REG_WIDTH - 1 : 0] cmpSecPwm0B_On;
wire   [`CMP_REG_WIDTH - 1 : 0] cmpSecPwm0B_Off;
wire   trigOut;


assign pwmCnt = 'b0;
assign cmpPriPwm0A_On = 'b0;
assign cmpPriPwm0A_Off = 'b0;
assign cmpPriPwm0B_On = 'b0;
assign cmpPriPwm0B_Off = 'b0;
assign cmpSecPwm0A_On = 'b0;
assign cmpSecPwm0A_Off = 'b0;
assign cmpSecPwm0B_On = 'b0;
assign cmpSecPwm0B_Off = 'b0;
assign trigOut = 'b0;


endmodule