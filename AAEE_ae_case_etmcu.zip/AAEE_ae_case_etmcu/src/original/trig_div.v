`include "common.vh"

module TRIG_DIV
(
	input      clk,
    input rst_n,
    input      trigIn,
    input [5:0]trigDiv,
    output     trigOut
);

reg reg_trigInPrev ;
reg [5:0] reg_trigDivCnt ;
reg reg_trigOut ;

always@(posedge clk or negedge rst_n) begin
    if(rst_n == 1'b0)begin
        reg_trigInPrev <= 'd0;
    end
    else begin
        reg_trigInPrev <= trigIn;
    end
end
    
always@(posedge clk or negedge rst_n) begin
    if(rst_n == 1'b0)begin
		reg_trigDivCnt <= 'd0;
    end
	// 在原始触发信号的上升沿，更新trigDivCnt
    else if((!reg_trigInPrev) && trigIn) begin
		if (reg_trigDivCnt + 1 < trigDiv) begin
			reg_trigDivCnt <= reg_trigDivCnt + 1;
		end
   		else begin
			reg_trigDivCnt <= 0;
    	end
    end
end

always@(posedge clk or negedge rst_n) begin
    if(rst_n == 1'b0)begin
		reg_trigOut <= 'd0;
    end
	// 仅第一个信号生效
	else if(reg_trigDivCnt == 0) begin
    	// 注意，reg_trigInPrev和reg_trigDivCnt为一个流水线
        // 不要误将reg_trigIn赋值给了输出
		// 否则会导致输出产生毛刺、分频异常
		reg_trigOut <= reg_trigInPrev;
    end
    else begin
		reg_trigOut <= 0;
    end
end

assign trigOut = reg_trigOut;

endmodule
