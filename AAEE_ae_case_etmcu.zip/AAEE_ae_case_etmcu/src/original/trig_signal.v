`include "common.vh"

module TRIG_SIGNAL
(
    input clk, 
    input rst_n,
    input rstN,
    output trigOut
);

localparam TIM_PRD = 960;

reg [11:0] reg_timer ;
reg reg_trigOut ;

always@(posedge clk or negedge rst_n) begin 
    if(rst_n == 1'b0)begin
        reg_timer <= 0;
    end
    else if ((reg_timer + 1 < TIM_PRD) && (rstN)) begin 
        reg_timer <= reg_timer + 1;
    end
    else begin 
        reg_timer <= 0;
    end
end

always@(posedge clk or negedge rst_n) begin 
    if(rst_n == 1'b0)begin
		reg_trigOut <= 0;
    end
	else if(reg_timer < (TIM_PRD >> 1)) begin
		reg_trigOut <= 1;
    end
    else begin
		reg_trigOut <= 0;
    end
end

assign trigOut = reg_trigOut;

endmodule
