module tz_ost
(
    input  clk, 
    input rst_n,

    input  tzSet,            /*tzSet连接至OC硬件比较器等硬件输出信号*/
    input  tzClr,            /*tzClr连接至MCU GPIO*/
    output tzLatch           /*tzSet为高则tzLatch置高，当tzSet为低且tzClr为高时tzLatch被清零*/
);

reg reg_tzLatch ;

always @ ( posedge clk or negedge rst_n ) begin
    if(rst_n == 1'b0)begin
        reg_tzLatch <= 0;
    end
    else if(tzSet)begin
        reg_tzLatch <= 1;
    end
    else begin
        if(tzClr)begin
            reg_tzLatch <= 0;
        end
    end
end

assign tzLatch = reg_tzLatch;

endmodule
