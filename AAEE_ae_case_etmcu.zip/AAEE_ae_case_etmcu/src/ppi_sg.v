//*************************************************************
// (C) COPYRIGHT ETMCU ALL RIGHTS RESERVED
// Filename             : ppi.v
// Author               : wanghong@etmcu.com
// Date                 : 2026-10-29
// Version              : v1.0
// Called By            : 
// Description          : 
//                        
// Modification History :
// Date        By             Version        Change Description
// 2026-10-29  wanghong	      v1.0           first version 
//*************************************************************

module  ppi_sg(
// ---------------- add for sg DAB -------------------
output [11:0] pwm_prd, cmp_pri_on_b, cmp_sec_on_a,
output [7:0] pri_pwm_db, sec_pwm_db,

// ---------------- add for sg DAB -------------------
input    sysclk,
input    sys_rstn,
input    [11:0]    PPI_DATA_BUS,
input    PPI_CSn,
input    [4:0]     PPI_ADDR,
output reg  [11:0]    PPI_DATA_OUT,

output   xorFail,
output   lenFail
);

reg    [11:0] reg_dataBuffer [( `PPI_CPLD_FRAME_LEN - 1):0] ; /*synopsys_keep*/
reg    [11:0] c2s_dataOut   [(`PPI_CPLD_FRAME_LEN - 1): 0];    /*synopsys_keep*/ 


reg [11:0] reg_xor12;
reg        PPI_CSn_1d;
reg [4:0]  ppi_addr_1d;

reg reg_xorFail;
reg reg_lenFail;

always@ (posedge sysclk or negedge sys_rstn) begin //for csn edge
    if (sys_rstn==1'b0) begin
        PPI_CSn_1d <= 1'b1;
        ppi_addr_1d <= 5'd0;
    end
    else begin
        PPI_CSn_1d <= PPI_CSn;
        ppi_addr_1d <= PPI_ADDR;
    end
end

reg   [4:0] i ;
always@ (posedge sysclk or negedge sys_rstn) begin
    if (sys_rstn==1'b0) begin
        for (i = 0; i < `PPI_CPLD_FRAME_LEN; i = i + 1) begin: label_cpld_par_bus_xx
            reg_dataBuffer[i] <= 12'd0;
        end
        reg_xor12   <= 12'd0;
    end
    else begin
        if (PPI_CSn==1'b0) begin
            reg_xor12 <= reg_xor12 ^ PPI_DATA_BUS;
            reg_dataBuffer[PPI_ADDR] <= PPI_DATA_BUS;
        end
        else begin
           reg_xor12  <= 12'd0;
        end
    end
end

always@ (posedge sysclk or negedge sys_rstn) begin
    if (sys_rstn==1'b0) begin
        reg_lenFail <= 0;
    end
    else begin
        if (PPI_CSn==1'b1 && PPI_CSn_1d==1'b0) begin //½áÊø
           if( `PPI_CPLD_FRAME_LEN-1 != PPI_ADDR) begin
               reg_lenFail <= 1;
           end
           else begin
               reg_lenFail <= 0;
           end
        end
    end
end

always@ (posedge sysclk or negedge sys_rstn) begin
    if (sys_rstn==1'b0) begin
        reg_xorFail <= 0;
    end
    else begin
        if (PPI_CSn==1'b1 && PPI_CSn_1d==1'b0) begin //½áÊø
           if (reg_xor12 == 12'hFFF) begin
               reg_xorFail <= 0;
           end
           else begin
               reg_xorFail <= 1;
           end
        end
    end
end

always@ (posedge sysclk or negedge sys_rstn) begin
    if (sys_rstn==1'b0) begin
        PPI_DATA_OUT <= 12'd0;
    end
    else begin
        if (PPI_CSn ==1'b0) begin
            PPI_DATA_OUT <= c2s_dataOut[PPI_ADDR];
        end
    end
end

//assign  dataOut = reg_dataBuffer;
assign  lenFail = reg_lenFail;
assign  xorFail = reg_xorFail;

reg   [4:0] j ;
always@ (posedge sysclk or negedge sys_rstn) begin
    if (sys_rstn==1'b0) begin
        for (j = 0; j < `PPI_CPLD_FRAME_LEN; j = j + 1) begin: label_cpld_par_outbus_xx
            c2s_dataOut[j] <= 12'h1+ j;
        end
    end
end
//-------------------------DAB------------------
assign pwm_prd      = reg_dataBuffer[0];
assign cmp_pri_on_b = reg_dataBuffer[1];
assign cmp_pri_on_a = reg_dataBuffer[2];
assign pri_pwm_db   = reg_dataBuffer[3][7:0];
assign sec_pwm_db   = reg_dataBuffer[4][7:0];
endmodule
//Local Variables:
//verilog-library-directories:("." "../../../common")
//End:

