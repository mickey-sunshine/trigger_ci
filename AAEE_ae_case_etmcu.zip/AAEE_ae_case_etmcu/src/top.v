//*************************************************************
// (C) COPYRIGHT ETMCU ALL RIGHTS RESERVED
// Filename             : top.v
// Author               : wanghong@etmcu.com
// Date                 : 2026-10-30
// Version              : v1.0
// Called By            : 
// Description          : 
//                        
// Modification History :
// Date        By             Version        Change Description
// 2026-10-30  wanghong       v1.0           first version 
//*************************************************************

module top #(
)
(
//-------------------------------------------------------------
//  sg  interface
//-------------------------------------------------------------
    input clk, input publish,
    input [2:0] work_mode_cmd,
    input ready_n, unlock_fault_n, normal_stop,
    input inv_oc_n, vg_pos_n, vg_neg,
    output S1,S2,S3,S4,S5,S6,S7,S8,
    output [2:0] mode,
    output inv_oc_latched, fault_latched, fsm_fault_latched, grid_fault_latched,
    output trig_out,
//-------------------------------------------------------------
//  ppi interface
//-------------------------------------------------------------
    input sys_rstn,
    
    input    [11:0]    PPI_DATA_BUS,
    input    PPI_CSn,
    input    [4:0]     PPI_ADDR,
    output      [11:0]    PPI_DATA_OUT 
);

//-------------------------------------------------------------
//  LOCAL Parameter
//-------------------------------------------------------------

//-------------------------------------------------------------
//  REG & Wire Definition
//-------------------------------------------------------------
/*autodef*/
/*AUTOWIRE*/
// Beginning of automatic wires (for undeclared instantiated-module outputs)
wire [11:0]             cmp_pri_on_b;           // From U_PPI_ET_MODIFY of ppi_sg.v
wire [11:0]             cmp_sec_on_a;           // From U_PPI_ET_MODIFY of ppi_sg.v
wire                    lenFail;                // From U_PPI_ET_MODIFY of ppi_sg.v
wire [7:0]              pri_pwm_db;             // From U_PPI_ET_MODIFY of ppi_sg.v
wire [11:0]             pwm_prd;                // From U_PPI_ET_MODIFY of ppi_sg.v
wire [7:0]              sec_pwm_db;             // From U_PPI_ET_MODIFY of ppi_sg.v
wire                    xorFail;                // From U_PPI_ET_MODIFY of ppi_sg.v
// End of automatics



ppi_sg U_PPI_ET_MODIFY (
                     .sysclk              (clk),
                     .sys_rstn          (sys_rstn),
                     
                     /*autoinst*/
                        // Outputs
                        .pwm_prd        (pwm_prd[11:0]),
                        .cmp_pri_on_b   (cmp_pri_on_b[11:0]),
                        .cmp_sec_on_a   (cmp_sec_on_a[11:0]),
                        .pri_pwm_db     (pri_pwm_db[7:0]),
                        .sec_pwm_db     (sec_pwm_db[7:0]),
                        .PPI_DATA_OUT   (PPI_DATA_OUT[11:0]),
                        .xorFail        (xorFail),
                        .lenFail        (lenFail),
                        // Inputs
                        .PPI_DATA_BUS   (PPI_DATA_BUS[11:0]),
                        .PPI_CSn        (PPI_CSn),
                        .PPI_ADDR       (PPI_ADDR[4:0]));

micinv_minimal_top U_SG_RTL(
                            .rst_n              (sys_rstn),
                            /*autoinst*/
                            // Outputs
                            .S1                 (S1),
                            .S2                 (S2),
                            .S3                 (S3),
                            .S4                 (S4),
                            .S5                 (S5),
                            .S6                 (S6),
                            .S7                 (S7),
                            .S8                 (S8),
                            .mode               (mode[2:0]),
                            .inv_oc_latched     (inv_oc_latched),
                            .fault_latched      (fault_latched),
                            .fsm_fault_latched  (fsm_fault_latched),
                            .grid_fault_latched (grid_fault_latched),
                            .trig_out           (trig_out),
                            // Inputs
                            .xorFail            (xorFail),
                            .clk                (clk),
                            .publish            (publish),
                            .work_mode_cmd      (work_mode_cmd[2:0]),
                            .pwm_prd            (pwm_prd[11:0]),
                            .cmp_pri_on_b       (cmp_pri_on_b[11:0]),
                            .cmp_sec_on_a       (cmp_sec_on_a[11:0]),
                            .pri_pwm_db         (pri_pwm_db[7:0]),
                            .sec_pwm_db         (sec_pwm_db[7:0]),
                            .ready_n            (ready_n),
                            .unlock_fault_n     (unlock_fault_n),
                            .normal_stop        (normal_stop),
                            .inv_oc_n           (inv_oc_n),
                            .vg_pos_n           (vg_pos_n),
                            .vg_neg             (vg_neg));
//-------------------------------------------------------------
//  Main Code
//-------------------------------------------------------------

endmodule
//Local Variables:
//verilog-library-directories:("." "../../../common" "../../../PPI")
//End:

